<template>
	<app-layout>
		<router-view />
	</app-layout>
</template>
