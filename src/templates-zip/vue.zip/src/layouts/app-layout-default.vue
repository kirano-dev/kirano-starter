<template>
	<slot></slot>
</template>

<style scoped lang="scss">

</style>