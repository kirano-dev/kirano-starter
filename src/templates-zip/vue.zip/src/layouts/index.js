export const AppLayoutsEnum = {
    default: "default",
}

export const AppLayoutToFileMap = {
    default: "app-layout-default.vue",
};
