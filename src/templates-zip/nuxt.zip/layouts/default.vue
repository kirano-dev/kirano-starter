<script setup>
</script>

<template>
	<main>
		<slot></slot>
	</main>
</template>

<style scoped lang="scss">

</style>